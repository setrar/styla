Just type "go" to compile and run JavaMain.java (tested with Java 6.29 and Scala 2.9.1).

You can customize JavaMain.java and simple.pl (the Prolog file it consults) to embedd Styla in your Java application. 

This directory contains a version of Scala (seen as a Java library). You might need to update these as Scala and Java progress through new versions over time.

Enjoy,

Paul Tarau

P.S. You can also try out interactively your programs by running the script "jstyla",
even if you do not have Scala installed.

