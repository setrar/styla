package prolog.terms
import scala.collection.mutable._

class Copier extends HashMap[Var, Var]
