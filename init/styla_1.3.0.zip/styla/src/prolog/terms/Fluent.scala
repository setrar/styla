package prolog.terms

trait Fluent extends SystemObject {
  def stop()
}