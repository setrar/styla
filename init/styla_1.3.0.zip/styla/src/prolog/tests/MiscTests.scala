package prolog.tests
import prolog._
import prolog.terms._
import prolog.io._

object go extends App {
  println("add tests here")
}
