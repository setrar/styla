package prolog

object Embed extends App {
  println("TODO")
}

