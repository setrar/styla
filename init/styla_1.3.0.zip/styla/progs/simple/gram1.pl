sent --> subj,pred,obj.
subj --> ng.
pred --> vg.
obj --> ng.

ng --> art,cn.
ng --> pn.

art --> [a].
art --> [the].

cn --> [cow].
cn --> [moon].

vg --> [jumps,over].
vg --> [admires].

pn --> ['Einstein'].
