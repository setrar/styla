% nothing here - only default db is used
 